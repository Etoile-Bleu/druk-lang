#pragma once

#include <string>

namespace druk::util
{

void checkUpdateAsync();
void printUpdateNotice(const std::string& currentVersion);

}  // namespace druk::util
