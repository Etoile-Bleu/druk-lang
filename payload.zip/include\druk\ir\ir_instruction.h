#pragma once

#include "druk/ir/ir_opcode.h"
#include "druk/ir/ir_instruction_base.h"
#include "druk/ir/ir_instruction_ops.h"
#include "druk/ir/ir_instruction_memory.h"
#include "druk/ir/ir_instruction_control.h"
#include "druk/ir/ir_instruction_arrays.h"
